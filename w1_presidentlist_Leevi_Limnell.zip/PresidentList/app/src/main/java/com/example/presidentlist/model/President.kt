package com.example.presidentlist.model

data class President(val name: String, val startYear: Int, val endYear: Int, val extra: String)